# pdiotapp
An application for data collection for PDIoT
