package com.specknet.pdiotapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Log
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.specknet.pdiotapp.bean.RecognitionResultBean
import com.specknet.pdiotapp.ml.MyRmodel
import com.specknet.pdiotapp.ml.MyTmodel
import com.specknet.pdiotapp.utils.Constants
import com.specknet.pdiotapp.utils.RESpeckLiveData
import com.specknet.pdiotapp.utils.RecognitionResultHelper
import com.specknet.pdiotapp.utils.ThingyLiveData
import org.tensorflow.lite.DataType
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import kotlin.math.roundToInt
import kotlin.math.sqrt

class RespeckAndThingyRecognitionActivity : AppCompatActivity() {

    // prediction text
    lateinit var predictionProgressBar: ProgressBar
    lateinit var predictionText: TextView

    lateinit var tvAction1: TextView
    lateinit var tvAction1Percent: TextView

    lateinit var tvAction2: TextView
    lateinit var tvAction2Percent: TextView

    lateinit var tvAction3: TextView
    lateinit var tvAction3Percent: TextView

    lateinit var tvAction4: TextView
    lateinit var tvAction4Percent: TextView

    lateinit var tvAction5: TextView
    lateinit var tvAction5Percent: TextView

    // 存储每个动作识别到的次数
    val map = mutableMapOf<String, Int>()
    var count=0


    val labels = listOf(
        "Sitting straight",
        "Sitting bent forward",
        "Sitting bent backward",
        "Standing",
        "Lying down left",
        "Lying down right",
        "Lying down front",
        "Lying down back",
        "Walking",
        "Running",
        "Ascending stairs",
        "Descending stairs",
        "Desk work",
        "General movement"
    )

    // 所有的动作概率
    val actionsMap = hashMapOf<String, Float>()

    private var lastlabel = ""


    var resProbabilityArray: FloatArray = FloatArray(14)
    var respeckPointsNum = 0f
    var respeckDataPack = java.util.ArrayList<Float>(300)

    lateinit var respeckLiveUpdateReceiver: BroadcastReceiver
    lateinit var looperRespeck: Looper
    val filterTestRespeck = IntentFilter(Constants.ACTION_RESPECK_LIVE_BROADCAST)


    var thingyProbabilityArray: FloatArray = FloatArray(14)
    var thingyPointsNum = 0f
    var thingyDataPack = java.util.ArrayList<Float>(300)

    lateinit var thingyLiveUpdateReceiver: BroadcastReceiver
    lateinit var looperThingy: Looper
    val filterTestThingy = IntentFilter(Constants.ACTION_THINGY_BROADCAST)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_respeck_and_thingy_recognition)

        predictionProgressBar = findViewById(R.id.predicted_activity)
        predictionText = findViewById(R.id.predicted_activity_text)

        tvAction1 = findViewById(R.id.tv_action1)
        tvAction1Percent = findViewById(R.id.action1_percent)

        tvAction2 = findViewById(R.id.tv_action2)
        tvAction2Percent = findViewById(R.id.action2_percent)

        tvAction3 = findViewById(R.id.tv_action3)
        tvAction3Percent = findViewById(R.id.action3_percent)

        tvAction4 = findViewById(R.id.tv_action4)
        tvAction4Percent = findViewById(R.id.action4_percent)

        tvAction5 = findViewById(R.id.tv_action5)
        tvAction5Percent = findViewById(R.id.action5_percent)




        respeckLiveUpdateReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {

                Log.i("thread", "I am running on thread = " + Thread.currentThread().name)

                val action = intent.action

                if (action == Constants.ACTION_RESPECK_LIVE_BROADCAST) {
                    val liveData =
                        intent.getSerializableExtra(Constants.RESPECK_LIVE_DATA) as RESpeckLiveData
                    Log.d("Live", "onReceive: liveData = " + liveData)

                    val x = liveData.accelX
                    val y = liveData.accelY
                    val z = liveData.accelZ
                    val gx = liveData.gyro.x
                    val gy = liveData.gyro.y
                    val gz = liveData.gyro.z
                    val mag = sqrt((x * x + y * y + z * z).toDouble())

                    respeckPointsNum += 1

                    respeckDataPack.addAll(
                        arrayListOf(
                            x, y, z, gx, gy, gz
                        )
                    )

                    if (respeckPointsNum >= 50) {
                        if (respeckPointsNum % 50 == 0f) {
                            val model = MyRmodel.newInstance(context)
                            // Creates inputs for reference.
                            val inputFeature0 =
                                TensorBuffer.createFixedSize(intArrayOf(1, 50, 6), DataType.FLOAT32)
                            inputFeature0.loadArray(respeckDataPack.toFloatArray())

                            // Runs model inference and gets result.
                            val outputs = model.process(inputFeature0)
                            val outputFeature0 = outputs.outputFeature0AsTensorBuffer
                            resProbabilityArray = outputFeature0.floatArray


                            val mergeClassifyResult =
                                mergeClassifyResult(resProbabilityArray, thingyProbabilityArray)

                            if (mergeClassifyResult != null) {
                                val tinyLstmConfidence =
                                    mergeClassifyResult.max()?.times(100)?.roundToInt()

                                if (lastlabel.isNotEmpty()) {

                                    when (lastlabel) {
                                        "Sitting straight", "Sitting bent forward", "Sitting bent backward", "Desk work" -> {
                                            mergeClassifyResult[9] = 0f
                                            mergeClassifyResult[10] = 0f
                                            mergeClassifyResult[11] = 0f

                                        }
                                        "Lying down left", "Lying down right", "Lying down front", "Lying down back" -> {
                                            mergeClassifyResult[8] = 0f
                                            mergeClassifyResult[9] = 0f
                                            mergeClassifyResult[10] = 0f
                                            mergeClassifyResult[11] = 0f
                                        }
                                        "Walking" -> {
                                            mergeClassifyResult[4] = 0f
                                            mergeClassifyResult[5] = 0f
                                            mergeClassifyResult[6] = 0f
                                            mergeClassifyResult[7] = 0f
                                        }
                                        "Running", "Ascending stairs", "Descending stairs" -> {
                                            mergeClassifyResult[0] = 0f
                                            mergeClassifyResult[1] = 0f
                                            mergeClassifyResult[2] = 0f
                                            mergeClassifyResult[4] = 0f
                                            mergeClassifyResult[5] = 0f
                                            mergeClassifyResult[6] = 0f
                                            mergeClassifyResult[7] = 0f
                                            mergeClassifyResult[12] = 0f
                                        }
                                    }

                                }


                                val label = getLabelText(mergeClassifyResult)
                                lastlabel = label
                                updateUI(label, tinyLstmConfidence)
                                Log.i("Tiny LSTM MODEL scheduleAtFixedRate", label)


                                // 识别到几个动作 map里面就会有几个key
                                map[label] = map[label]?.plus(1) ?: 1


                                // [0.10,0.46]
                                mergeClassifyResult.forEachIndexed { index, fl ->
                                    actionsMap[labels[index]] = fl
                                }

                                // actionsMap.entries.sortedBy {  }
                                val result = actionsMap.entries.sortedByDescending { it.value }
                                val entry1 = result[1]
                                val entry2 = result[2]
                                val entry3 = result[3]
                                val entry4 = result[4]
                                val entry5 = result[5]

                                runOnUiThread {
                                    tvAction1.text = entry1.key
                                    tvAction1Percent.text =
                                        entry1.value.times(100)?.roundToInt().toString() + "%"

                                    tvAction2.text = entry2.key
                                    tvAction2Percent.text =
                                        entry2.value.times(100)?.roundToInt().toString() + "%"

                                    tvAction3.text = entry3.key
                                    tvAction3Percent.text =
                                        entry3.value.times(100)?.roundToInt().toString() + "%"

                                    tvAction4.text = entry4.key
                                    tvAction4Percent.text =
                                        entry4.value.times(100)?.roundToInt().toString() + "%"

                                    tvAction5.text = entry5.key
                                    tvAction5Percent.text =
                                        entry5.value.times(100)?.roundToInt().toString() + "%"
                                }


                            }


                        }

                        respeckDataPack = java.util.ArrayList(respeckDataPack.drop(6))
                    }

                }
            }
        }

        // set up the broadcast receiver
        thingyLiveUpdateReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {

                Log.i("thread", "I am running on thread = " + Thread.currentThread().name)

                val action = intent.action

                if (action == Constants.ACTION_THINGY_BROADCAST) {

                    val liveData =
                        intent.getSerializableExtra(Constants.THINGY_LIVE_DATA) as ThingyLiveData
                    Log.d("Live", "onReceive: liveData = " + liveData)

                    val x = liveData.accelX
                    val y = liveData.accelY
                    val z = liveData.accelZ
                    val gx = liveData.gyro.x
                    val gy = liveData.gyro.y
                    val gz = liveData.gyro.z
                    val mag = sqrt((x * x + y * y + z * z).toDouble())
                    thingyPointsNum += 1
                    thingyDataPack.addAll(
                        arrayListOf(
                            x, y, z, gx, gy, gz
                        )
                    )

                    if (thingyPointsNum >= 50) {

                        if (thingyPointsNum % 50 == 0f) {

                            val model = MyTmodel.newInstance(context)

                            // Creates inputs for reference.
                            val inputFeature0 =
                                TensorBuffer.createFixedSize(intArrayOf(1, 50, 6), DataType.FLOAT32)
                            inputFeature0.loadArray(thingyDataPack.toFloatArray())

                            // Runs model inference and gets result.
                            val outputs = model.process(inputFeature0)
                            val outputFeature0 = outputs.outputFeature0AsTensorBuffer

                            thingyProbabilityArray = outputFeature0.floatArray


                            val mergeClassifyResult =
                                mergeClassifyResult(resProbabilityArray, thingyProbabilityArray)

                            if (mergeClassifyResult != null) {
                                val tinyLstmConfidence =
                                    mergeClassifyResult.max()?.times(100)?.roundToInt()

                                if (lastlabel.isNotEmpty()) {

                                    when (lastlabel) {
                                        "Sitting straight", "Sitting bent forward", "Sitting bent backward", "Desk work" -> {
                                            mergeClassifyResult[9] = 0f
                                            mergeClassifyResult[10] = 0f
                                            mergeClassifyResult[11] = 0f

                                        }
                                        "Lying down left", "Lying down right", "Lying down front", "Lying down back" -> {
                                            mergeClassifyResult[8] = 0f
                                            mergeClassifyResult[9] = 0f
                                            mergeClassifyResult[10] = 0f
                                            mergeClassifyResult[11] = 0f
                                        }
                                        "Walking" -> {
                                            mergeClassifyResult[4] = 0f
                                            mergeClassifyResult[5] = 0f
                                            mergeClassifyResult[6] = 0f
                                            mergeClassifyResult[7] = 0f
                                        }
                                        "Running", "Ascending stairs", "Descending stairs" -> {
                                            mergeClassifyResult[0] = 0f
                                            mergeClassifyResult[1] = 0f
                                            mergeClassifyResult[2] = 0f
                                            mergeClassifyResult[4] = 0f
                                            mergeClassifyResult[5] = 0f
                                            mergeClassifyResult[6] = 0f
                                            mergeClassifyResult[7] = 0f
                                            mergeClassifyResult[12] = 0f
                                        }
                                    }

                                }


                                val label = getLabelText(mergeClassifyResult)
                                lastlabel = label

                                if (label == "Sitting straight" || label == "Sitting bent forward" || label == "Sitting bent backward" || label == "Desk work") {
                                    count += 1
                                    if(count==5){
                                        runOnUiThread {
                                            Toast.makeText(this@RespeckAndThingyRecognitionActivity, "Sitting too long, Please relax for a while", Toast.LENGTH_SHORT).show()
                                        }
                                        count=0
                                    }
                                }
                                else count=0


                                updateUI(label, tinyLstmConfidence)
                                Log.i("Tiny LSTM MODEL scheduleAtFixedRate", label)


                                // 识别到几个动作 map里面就会有几个key
                                map[label] = map[label]?.plus(1) ?: 1


                                // [0.10,0.46]
                                mergeClassifyResult.forEachIndexed { index, fl ->
                                    actionsMap[labels[index]] = fl
                                }

                                // actionsMap.entries.sortedBy {  }
                                val result = actionsMap.entries.sortedByDescending { it.value }
                                val entry1 = result[1]
                                val entry2 = result[2]
                                val entry3 = result[3]
                                val entry4 = result[4]
                                val entry5 = result[5]

                                runOnUiThread {
                                    tvAction1.text = entry1.key
                                    tvAction1Percent.text =
                                        entry1.value.times(100)?.roundToInt().toString() + "%"

                                    tvAction2.text = entry2.key
                                    tvAction2Percent.text =
                                        entry2.value.times(100)?.roundToInt().toString() + "%"

                                    tvAction3.text = entry3.key
                                    tvAction3Percent.text =
                                        entry3.value.times(100)?.roundToInt().toString() + "%"

                                    tvAction4.text = entry4.key
                                    tvAction4Percent.text =
                                        entry4.value.times(100)?.roundToInt().toString() + "%"

                                    tvAction5.text = entry5.key
                                    tvAction5Percent.text =
                                        entry5.value.times(100)?.roundToInt().toString() + "%"
                                }


                            }


                        }

                        thingyDataPack = java.util.ArrayList(thingyDataPack.drop(6))
                    }

                }
            }
        }


        // register receiver on another thread
        val handlerThreadThingy = HandlerThread("bgThreadThingyLive")
        handlerThreadThingy.start()
        looperThingy = handlerThreadThingy.looper
        val handlerThingy = Handler(looperThingy)
        this.registerReceiver(thingyLiveUpdateReceiver, filterTestThingy, null, handlerThingy)


        val handlerThreadRespeck = HandlerThread("bgThreadRespeckLive")
        handlerThreadRespeck.start()
        looperRespeck = handlerThreadRespeck.looper
        val handlerRespeck = Handler(looperRespeck)
        this.registerReceiver(respeckLiveUpdateReceiver, filterTestRespeck, null, handlerRespeck)


        /*// 第一个传感器
        RecognitionDataManager.onRESpeckDataUpdate = { dataList: List<RESpeckLiveData> ->
            if (dataList.isNotEmpty()) {
                Log.d("Live", "onReceive: liveData = " + dataList[0])
                val liveData = dataList[0]
                val x = liveData.accelX
                val y = liveData.accelY
                val z = liveData.accelZ
                val gx = liveData.gyro.x
                val gy = liveData.gyro.y
                val gz = liveData.gyro.z

                // for循环 push5次
                dataList.forEach {
                    // new tflite model
                    respeckModel.pushNewData(x, y, z, gx, gy, gz)
                }
                // 满五个数据才调用一次
                val mergeClassifyResult = respeckModel.classify()
                lastRespeckClassifyResult = mergeClassifyResult[0]
            }
        }


        // 第二个传感器
        RecognitionDataManager.onThingyDataUpdate = { dataList: List<ThingyLiveData> ->
            if (dataList.isNotEmpty()) {
                Log.d("Live", "onReceive: liveData = " + dataList[0])
                val liveData = dataList[0]
                val x = liveData.accelX
                val y = liveData.accelY
                val z = liveData.accelZ
                val gx = liveData.gyro.x
                val gy = liveData.gyro.y
                val gz = liveData.gyro.z

                // for循环 push5次
                dataList.forEach {
                    // new tflite model
                    thingyModel.pushNewData(x, y, z, gx, gy, gz)
                }
                // 满五个数据才调用一次
                val mergeClassifyResult = thingyModel.classify()
                lastThingyClassifyResult = mergeClassifyResult[0]
            }

        }*/
    }


    fun getLabelText(predictions: FloatArray): String {
        var max = Float.MIN_VALUE
        var maxIdx = -1
        for (i in labels.indices) {
            if (predictions[i] > max) {
                max = predictions[i]
                maxIdx = i
            }
        }
        return labels[maxIdx]
    }

    fun updateUI(prediction: String, confidence: Int?) {
        runOnUiThread {
            predictionProgressBar.progress = confidence as Int
            predictionText.text = prediction

        }
    }

    /**
     * 合并预测结果
     *
     * [0.1,0.001,0.03]
     *
     * [ [0.1,0.001,0.03] ]
     *
     * 默许输入的参数 长度都是outputClasses的大小
     */
    fun mergeClassifyResult(respeckResult: FloatArray?, thingyResult: FloatArray?): FloatArray? {

        if (respeckResult == null && thingyResult == null) {
            return null
        }
        if (respeckResult == null) {
            return thingyResult
        }
        if (thingyResult == null) {
            return respeckResult
        }

//   0     "Sitting straight",
//    1    "Sitting bent forward",
//    2    "Sitting bent backward",
//    3    "Standing",
//    4    "Lying down left",
//    5    "Lying down right",
//    6    "Lying down front",
//    7    "Lying down back",
//    8    "Walking",
//    9    "Running",
//    10    "Ascending stairs",
//    11    "Descending stairs",
//        "Desk work",
//        "General movement"

        val result = FloatArray(14)

        result[0] = respeckResult[0] * 0.4f + thingyResult[0] * 0.6f
        result[1] = respeckResult[1] * 0.6f + thingyResult[1] * 0.4f
        result[2] = respeckResult[2] * 0.6f + thingyResult[2] * 0.4f
        result[3] = respeckResult[3] * 0.4f + thingyResult[3] * 0.6f
        result[4] = respeckResult[4]
        result[5] = respeckResult[5]
        result[6] = respeckResult[6]
        result[7] = respeckResult[7]
        result[8] = respeckResult[8] * 0.7f + thingyResult[8] * 0.3f
        result[9] = respeckResult[9] * 0.7f + thingyResult[9] * 0.3f
        result[10] = respeckResult[10] * 0.4f + thingyResult[10] * 0.6f
        result[11] = respeckResult[11] * 0.4f + thingyResult[11] * 0.6f
        result[12] = respeckResult[12] * 0.5f + thingyResult[12] * 0.5f
        result[13] = respeckResult[13] * 0.5f + thingyResult[13] * 0.5f

//        respeckResult.forEachIndexed { index, fl ->
//            result[index] = (fl + thingyResult[index]) / 2f
//        }
        return result

    }

    override fun onDestroy() {

        unregisterReceiver(respeckLiveUpdateReceiver)
        looperRespeck.quit()

        unregisterReceiver(thingyLiveUpdateReceiver)
        looperThingy.quit()

        val list = ArrayList<RecognitionResultBean>()
        map.forEach { (label, count) ->
            list.add(RecognitionResultBean(System.currentTimeMillis(), label, count, "respeck"))
        }
        // 页面关闭的时候把数据存入本地
        if (list.isNotEmpty()) {
            // 存储在本地
            RecognitionResultHelper.saveUserRecognitionData(list)
        }
        // 先执行我们的代码 再Destroy
        super.onDestroy()
    }


}