package com.specknet.pdiotapp.common

import com.specknet.pdiotapp.utils.RESpeckLiveData
import com.specknet.pdiotapp.utils.ThingyLiveData

/**
 * 实时数据
 * 中转站
 */
object RecognitionDataManager {

    var onRESpeckDataUpdate: ((dataList: List<RESpeckLiveData>) -> Unit)? = null
    var onThingyDataUpdate: ((dataList: List<ThingyLiveData>) -> Unit)? = null

    /**
     * 接受蓝牙数据
     * 接受到之后 转发给监听者
     * 一次性接受多个数据
     */
    fun sendRESpeckData(dataList: List<RESpeckLiveData>) {
        onRESpeckDataUpdate?.invoke(dataList)
    }


    /**
     * 接受蓝牙数据
     * 接受到之后 转发给监听者
     * 一次性接受多个数据
     */
    fun sendThingyData(dataList: List<ThingyLiveData>) {
        onThingyDataUpdate?.invoke(dataList)
    }


}