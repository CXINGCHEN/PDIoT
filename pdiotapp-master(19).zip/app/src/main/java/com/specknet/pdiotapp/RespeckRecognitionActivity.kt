package com.specknet.pdiotapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Log
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet
import com.specknet.pdiotapp.bean.RecognitionResultBean
import com.specknet.pdiotapp.ml.MyRmodel
import com.specknet.pdiotapp.utils.Constants
import com.specknet.pdiotapp.utils.RESpeckLiveData
import com.specknet.pdiotapp.utils.RecognitionResultHelper
import org.tensorflow.lite.DataType
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import kotlin.math.roundToInt
import kotlin.math.sqrt

class RespeckRecognitionActivity : AppCompatActivity() {

    // prediction text
    lateinit var predictionProgressBar: ProgressBar
    lateinit var predictionText: TextView


    // global graph variables
    lateinit var dataSet_x: LineDataSet
    lateinit var dataSet_y: LineDataSet
    lateinit var dataSet_z: LineDataSet
    lateinit var dataSet_mag: LineDataSet
    lateinit var allAccelData: LineData
    lateinit var chart: LineChart


    private var lastlabel = ""

    var resProbabilityArray: FloatArray = FloatArray(14)
    var respeckPointsNum = 0f
    var respeckDataPack = java.util.ArrayList<Float>(300)

    lateinit var respeckLiveUpdateReceiver: BroadcastReceiver
    lateinit var looperRespeck: Looper
    val filterTestRespeck = IntentFilter(Constants.ACTION_RESPECK_LIVE_BROADCAST)


    // 存储每个动作识别到的次数
    val map = mutableMapOf<String, Int>()
    var count = 0/////////////////////////////////////////////////////////////


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_respeck_recognition)

        predictionProgressBar = findViewById(R.id.predicted_activity)
        predictionText = findViewById(R.id.predicted_activity_text)


        // get the accel fields
        val accel_x = findViewById<TextView>(R.id.live_x_accel_data)
        val accel_y = findViewById<TextView>(R.id.live_y_accel_data)
        val accel_z = findViewById<TextView>(R.id.live_z_accel_data)
        val gryo_x = findViewById<TextView>(R.id.live_gyro_x_data)
        val gryo_y = findViewById<TextView>(R.id.live_gyro_y_data)
        val gryo_z = findViewById<TextView>(R.id.live_gyro_z_data)

        setupGraph()


        // set up the broadcast receiver
        respeckLiveUpdateReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {

                Log.i("thread", "I am running on thread = " + Thread.currentThread().name)

                val action = intent.action

                if (action == Constants.ACTION_RESPECK_LIVE_BROADCAST) {

                    val liveData =
                        intent.getSerializableExtra(Constants.RESPECK_LIVE_DATA) as RESpeckLiveData
                    Log.d("Live", "onReceive: liveData = " + liveData)

                    val x = liveData.accelX
                    val y = liveData.accelY
                    val z = liveData.accelZ
                    val gx = liveData.gyro.x
                    val gy = liveData.gyro.y
                    val gz = liveData.gyro.z
                    val mag = sqrt((x * x + y * y + z * z).toDouble())


                    respeckPointsNum += 1


                    respeckDataPack.addAll(
                        arrayListOf(
                            x, y, z, gx, gy, gz
                        )
                    )

                    if (respeckPointsNum >= 50) {

                        if (respeckPointsNum % 50 == 0f) {

                            val model = MyRmodel.newInstance(context)

                            // Creates inputs for reference.
                            val inputFeature0 =
                                TensorBuffer.createFixedSize(intArrayOf(1, 50, 6), DataType.FLOAT32)
                            inputFeature0.loadArray(respeckDataPack.toFloatArray())

                            // Runs model inference and gets result.
                            val outputs = model.process(inputFeature0)
                            val outputFeature0 = outputs.outputFeature0AsTensorBuffer
                            resProbabilityArray = outputFeature0.floatArray

                            if (lastlabel.isNotEmpty()) {
                                when (lastlabel) {
                                    "Sitting straight", "Sitting bent forward", "Sitting bent backward", "Desk work" -> {
                                        resProbabilityArray[9] = 0f
                                        resProbabilityArray[10] = 0f
                                        resProbabilityArray[11] = 0f

                                    }
                                    "Lying down left", "Lying down right", "Lying down front", "Lying down back" -> {
                                        resProbabilityArray[8] = 0f
                                        resProbabilityArray[9] = 0f
                                        resProbabilityArray[10] = 0f
                                        resProbabilityArray[11] = 0f
                                    }
                                    "Walking" -> {
                                        resProbabilityArray[4] = 0f
                                        resProbabilityArray[5] = 0f
                                        resProbabilityArray[6] = 0f
                                        resProbabilityArray[7] = 0f
                                    }
                                    "Running", "Ascending stairs", "Descending stairs" -> {
                                        resProbabilityArray[0] = 0f
                                        resProbabilityArray[1] = 0f
                                        resProbabilityArray[2] = 0f
                                        resProbabilityArray[4] = 0f
                                        resProbabilityArray[5] = 0f
                                        resProbabilityArray[6] = 0f
                                        resProbabilityArray[7] = 0f
                                        resProbabilityArray[12] = 0f
                                    }
                                }

                            }


                            //  返回的第0
                            val tinyLstmConfidence =
                                resProbabilityArray.max()?.times(100)?.roundToInt()
                            val label = getLabelText(resProbabilityArray)
                            if (label == "Sitting straight" || label == "Sitting bent forward" || label == "Sitting bent backward" || label == "Desk work") {
                                count += 1
                                if(count==5){
                                    runOnUiThread {
                                        Toast.makeText(this@RespeckRecognitionActivity, "Sitting too long, Please relax for a while", Toast.LENGTH_SHORT).show()
                                    }
                                    count=0
                                }
                            }
                            else count=0

                            lastlabel = label
                            updateUI(label, tinyLstmConfidence)
                            Log.i("Tiny LSTM MODEL", label)

                            // 识别到几个动作 map里面就会有几个key
                            map[label] = map[label]?.plus(1) ?: 1

                            // Releases model resources if no longer used.
                            model.close()

                        }

                        respeckDataPack = java.util.ArrayList(respeckDataPack.drop(6))

                    }

                    //  ---  Graph  ---

                    runOnUiThread {
                        accel_x.text = "accel_x = $x"
                        accel_y.text = "accel_y = $y"
                        accel_z.text = "accel_z = $z"
                        gryo_x.text = "gryo_x = $gx"
                        gryo_y.text = "gryo_y = $gy"
                        gryo_z.text = "gryo_z = $gz"
                    }
                    updateGraph(x, y, z)

                }
            }
        }

        val handlerThreadRespeck = HandlerThread("bgThreadRespeckLive")
        handlerThreadRespeck.start()
        looperRespeck = handlerThreadRespeck.looper
        val handlerRespeck = Handler(looperRespeck)
        this.registerReceiver(respeckLiveUpdateReceiver, filterTestRespeck, null, handlerRespeck)

    }


    val labels = listOf(
        "Sitting straight",
        "Sitting bent forward",
        "Sitting bent backward",
        "Standing",
        "Lying down left",
        "Lying down right",
        "Lying down front",
        "Lying down back",
        "Walking",
        "Running",
        "Ascending stairs",
        "Descending stairs",
        "Desk work",
        "General movement"
    )


    fun getLabelText(predictions: FloatArray): String {
        var max = Float.MIN_VALUE
        var maxIdx = -1
        for (i in labels.indices) {
            if (predictions[i] > max) {
                max = predictions[i]
                maxIdx = i
            }
        }
        return labels[maxIdx]
    }


    private fun setupGraph() {
        chart = findViewById(R.id.chart)

        //-----------------
        val entries_x = ArrayList<Entry>()
        val entries_y = ArrayList<Entry>()
        val entries_z = ArrayList<Entry>()
        val entries_mag = ArrayList<Entry>()

        dataSet_x = LineDataSet(entries_x, "Accel X")
        dataSet_y = LineDataSet(entries_y, "Accel Y")
        dataSet_z = LineDataSet(entries_z, "Accel Z")

        //-------------------------

        dataSet_mag = LineDataSet(entries_mag, "Magnitude")

        dataSet_x.setDrawCircles(false)
        dataSet_y.setDrawCircles(false)
        dataSet_z.setDrawCircles(false)

        dataSet_mag.setDrawCircles(false)

        dataSet_x.setColor(
            ContextCompat.getColor(
                this, R.color.red
            )
        )
        dataSet_y.setColor(
            ContextCompat.getColor(
                this, R.color.green
            )
        )
        dataSet_z.setColor(
            ContextCompat.getColor(
                this, R.color.blue
            )
        )

        dataSet_mag.setColor(
            ContextCompat.getColor(
                this, R.color.yellow
            )
        )

        val dataSets = ArrayList<ILineDataSet>()
        dataSets.add(dataSet_x)
        dataSets.add(dataSet_y)
        dataSets.add(dataSet_z)
        dataSets.add(dataSet_mag)

        allAccelData = LineData(dataSets)
        chart.data = allAccelData
        // 控件重绘
        chart.invalidate()
    }

    fun updateGraph(x: Float, y: Float, z: Float) {

        dataSet_x.addEntry(Entry(respeckPointsNum, x))
        dataSet_y.addEntry(Entry(respeckPointsNum, y))
        dataSet_z.addEntry(Entry(respeckPointsNum, z))


        runOnUiThread {
            allAccelData.notifyDataChanged()
            chart.notifyDataSetChanged()
            chart.invalidate()
            chart.setVisibleXRangeMaximum(150f)
            chart.moveViewToX(chart.lowestVisibleX + 40)
        }
    }

    fun updateUI(prediction: String, confidence: Int?) {
        runOnUiThread {
            predictionProgressBar.progress = confidence as Int
            predictionText.text = prediction
        }
    }

    override fun onDestroy() {

        unregisterReceiver(respeckLiveUpdateReceiver)
        looperRespeck.quit()

        val list = ArrayList<RecognitionResultBean>()
        map.forEach { (label, count) ->
            list.add(RecognitionResultBean(System.currentTimeMillis(), label, count, "respeck"))
        }
        // 页面关闭的时候把数据存入本地
        if (list.isNotEmpty()) {
            // 存储在本地
            RecognitionResultHelper.saveUserRecognitionData(list)
        }
        // 先执行我们的代码 再Destroy
        super.onDestroy()
    }
}