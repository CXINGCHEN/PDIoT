package com.specknet.pdiotapp.common

import android.content.res.AssetManager
import org.tensorflow.lite.Interpreter
import java.io.*


// outputClasses = 6
class TFLiteModelByFile(
    assetManager: AssetManager,
    file: File,
    labelPath: String,
    private val outputClasses: Int,
    inputTensorLength: Int
) {

    private var interpreter: Interpreter
    private var labelList: List<String>
    private val inputTensorData = AccelerometerData(inputTensorLength, 6)

    // 最先執行
    init {
        interpreter = Interpreter(file, Interpreter.Options())
        labelList = this.loadLabelList(assetManager, labelPath)
    }

    @Throws(IOException::class)
    private fun loadLabelList(assetManager: AssetManager, labelPath: String): List<String> {
        val labelList: MutableList<String> = ArrayList()
        val reader = BufferedReader(InputStreamReader(assetManager.open(labelPath)))
        while (true) {
            val line = reader.readLine()
            if (line != null) {
                labelList.add(line)
            } else {
                break
            }
        }
        reader.close()
        return labelList
    }

    // 识别
    fun classify(): Array<FloatArray> {
        val output = arrayOf(FloatArray(outputClasses))
        interpreter.run(inputTensorData.getData(), output)
        return output
    }

    fun getLabelText(predictions: Array<FloatArray>): String {
        var max = Float.MIN_VALUE
        var maxIdx = -1
        for (i in labelList.indices) {
            if (predictions[0][i] > max) {
                max = predictions[0][i]
                maxIdx = i
            }
        }
        return labelList[maxIdx]
    }

    fun pushNewData(x: Float, y: Float, z: Float, gyro_x: Float, gyro_y: Float, gyro_z: Float) {
        inputTensorData.pushNewData(x, y, z, gyro_x, gyro_y, gyro_z)
    }
}