package com.specknet.pdiotapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.specknet.pdiotapp.bean.User;
import com.specknet.pdiotapp.utils.Constants;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity {


    private EditText etName;
    private EditText etEmail;
    private EditText etPwd;
    private EditText etPwd2;
    private Button btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etName = findViewById(R.id.et_name);
        etEmail = findViewById(R.id.et_email);
        etPwd = findViewById(R.id.et_password);
        etPwd2 = findViewById(R.id.et_password2);
        btnRegister = findViewById(R.id.btn_register);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 保存用户填写的信息
                registerUserInfo();
            }
        });


    }

    private void registerUserInfo() {
        // 获取用户输入的姓名
        String name = etName.getText().toString();
        String email = etEmail.getText().toString();
        String pwd = etPwd.getText().toString();
        String pwd2 = etPwd2.getText().toString();

        // trim 去掉两边的空格

        if (name.trim().equals("")) {
            Toast.makeText(this, "Please enter user name", Toast.LENGTH_SHORT).show();
            return;
        }

        if (email.trim().equals("")) {
            Toast.makeText(this, "Please enter email", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!checkEmail(email.trim())) {
            Toast.makeText(this, "Wrong email", Toast.LENGTH_SHORT).show();
            return;
        }

        if (pwd.trim().equals("")) {
            Toast.makeText(this, "Please enter password", Toast.LENGTH_SHORT).show();
            return;
        }

        if (pwd2.trim().equals("")) {
            Toast.makeText(this, "Please confirm password", Toast.LENGTH_SHORT).show();
            return;
        }

        if (pwd.trim().equals(pwd2.trim())) {
            // 两次输入密码一样
            saveUserInfo(name, email, pwd);
        } else {
            Toast.makeText(this, "Password not the same", Toast.LENGTH_SHORT).show();
        }

    }


    /**
     * 保存到本地
     * sp
     * [{name:"",email:"",pwd:""},{name:"",email:"",pwd:""},{name:"",email:"",pwd:""}]
     */
    private void saveUserInfo(String name, String email, String pwd) {

        SharedPreferences sharedPreferences = getSharedPreferences(Constants.PREFERENCES_FILE, Context.MODE_PRIVATE);

        // 判断本地有没有该用户
        if (sharedPreferences.contains(Constants.SHARE_PREF_USER_LIST)) {

            String userListString = sharedPreferences.getString(Constants.SHARE_PREF_USER_LIST, "");
            Gson gson = new Gson();
            // 字符串转成 list
            List<User> userArrayList = gson.fromJson(userListString, new TypeToken<List<User>>() {
            }.getType());

            // 如果list 不为空 里面有用户了

            boolean hasRegistered = false;
            if (userArrayList != null && userArrayList.size() > 0 ) {
                for (int i = 0; i < userArrayList.size(); i++) {
                    User user = userArrayList.get(i);
                    String localUserEmail = user.getEmail();
                    if (localUserEmail.equals(email)) {
                        // 本地有该用户 不能重复注册
                        hasRegistered = true;
                    }
                }
            }

            if (hasRegistered) {
                Toast.makeText(this, "User already exist", Toast.LENGTH_SHORT).show();
            } else {
                User user = new User(name, email, pwd);
                if (userArrayList !=  null) {
                    userArrayList.add(user);
                } else  {
                    userArrayList = new ArrayList<>();
                    userArrayList.add(user);
                }
                // 转成字符串 保存在本地 转json存本地
                String s = gson.toJson(userArrayList);
                sharedPreferences.edit().putString(Constants.SHARE_PREF_USER_LIST,s).commit();
                Toast.makeText(this, "Register successful", Toast.LENGTH_SHORT).show();

                // 关闭当前页面
                finish();

            }

        } else  {
            // 首次注册用户
            User user = new User(name, email, pwd);
            // 空list对象
            ArrayList<User> list = new ArrayList<>();
            list.add(user);
            // 转成字符串 保存在本地 转json存本地
            Gson gson = new Gson();
            String s = gson.toJson(list);
            sharedPreferences.edit().putString(Constants.SHARE_PREF_USER_LIST,s).commit();
            Toast.makeText(this, "Register successful", Toast.LENGTH_SHORT).show();

            // 关闭当前页面
            finish();
        }

    }

    /**
     *     * 正则表达式校验邮箱
     * <p>
     *     * @param email 待匹配的邮箱
     * <p>
     *   * @return匹配成功返回true 否则返回false;
     * <p>
     *    
     */

    private static boolean checkEmail(String email) {

        String RULE_EMAIL = "^\\w+((-\\w+)|(\\.\\w+))*\\@[A-Za-z0-9]+((\\.|-)[A-Za-z0-9]+)*\\.[A-Za-z0-9]+$";
        //正则表达式的模式
        Pattern p = Pattern.compile(RULE_EMAIL);
        //正则表达式的匹配器
        Matcher m = p.matcher(email);
        //进行正则匹配
        return m.matches();
    }


}