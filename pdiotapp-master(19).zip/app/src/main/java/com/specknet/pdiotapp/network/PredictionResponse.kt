package com.specknet.pdiotapp.network

import com.google.gson.Gson

class PredictionResponse {
    val result = arrayOf(FloatArray(14))

    override fun toString(): String {
        return Gson().toJson(result)
    }
}