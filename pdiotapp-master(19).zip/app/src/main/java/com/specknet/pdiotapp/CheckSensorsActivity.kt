package com.specknet.pdiotapp

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.specknet.pdiotapp.common.RecognitionDataManager
import com.specknet.pdiotapp.utils.RESpeckLiveData

class CheckSensorsActivity : AppCompatActivity() {


    lateinit var stepOneResult: TextView
    lateinit var stepTwoResult: TextView

    var stepOneList = mutableListOf<RESpeckLiveData>()
    var stepTwoList = mutableListOf<RESpeckLiveData>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_check_sensors)
        stepOneResult = findViewById(R.id.tv_step_one_result)
        stepTwoResult = findViewById(R.id.tv_step_two_result)
    }


    /**
     * 坐好
     */
    fun stepOneStart(view: View) {

        stepOneList.clear()
        stepOneResult.text = "Checking..."

        // 保存五十个数据
        RecognitionDataManager.onRESpeckDataUpdate = { dataList: List<RESpeckLiveData> ->
            if (stepTwoList.size < 50) {
                stepTwoList.addAll(dataList)
            } else {
                // 不在接受新的数据
                RecognitionDataManager.onRESpeckDataUpdate = null
                val averageX = stepTwoList.map { it.accelX }.average()
                val averageY = stepTwoList.map { it.accelY }.average()
                val averageZ = stepTwoList.map { it.accelZ }.average()
                Log.d("TAG", "averageX=${averageX},averageY=${averageY},averageZ=${averageZ}")
                if ((averageX < 0.3 && averageX > -0.3) && (averageY < -0.8 && averageY > -1.2) && (averageZ < 0.3 && averageZ > -0.3)) {
                    runOnUiThread {
                        stepOneResult.text = "Sensor position OK"
                    }
                } else {
                    runOnUiThread {
                        stepOneResult.text = "Wrong position, please adjust"
                    }
                }

            }

        }


    }

    /**
     * 躺好
     */
    fun stepTwoStart(view: View) {

        stepTwoList.clear()
        stepTwoResult.text = "Checking..."

        // 保存五十个数据
        RecognitionDataManager.onRESpeckDataUpdate = { dataList: List<RESpeckLiveData> ->

            if (stepOneList.size < 50) {
                stepOneList.addAll(dataList)
            } else {
                // 不在接受新的数据
                RecognitionDataManager.onRESpeckDataUpdate = null

                val averageX = stepOneList.map { it.accelX }.average()
                val averageY = stepOneList.map { it.accelY }.average()
                val averageZ = stepOneList.map { it.accelZ }.average()
                Log.d("TAG", "averageX=${averageX},averageY=${averageY},averageZ=${averageZ}")

                val lyingOne = (averageX < 0.3 && averageX > -0.3) && (averageY < 0.3 && averageY > -0.3) && (averageZ > 0.8 && averageZ < 1.2)
                val lyingTwo = (averageX < 0.3 && averageX > -0.3) && (averageY < 0.3 && averageY > -0.3) && (averageZ > 0.8 && averageZ < 1.2)
                val lyingThree = (averageX < 0 && averageX > -0.6) && (averageY < 0.3 && averageY > -0.3) && (averageZ > 0.8 && averageZ < 1.2)

                if (lyingOne || lyingTwo || lyingThree) {
                    runOnUiThread {
                        stepTwoResult.text = "Sensor position OK"
                    }
                } else {
                    runOnUiThread {
                        stepTwoResult.text = "Wrong position, please adjust"
                    }
                }

            }

        }

    }
}