package com.specknet.pdiotapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.specknet.pdiotapp.bean.User;
import com.specknet.pdiotapp.utils.Constants;

import java.util.List;

public class LoginActivity extends AppCompatActivity {

    ImageView imageView;
    TextView textView;
    int count = 0;

    private EditText etEmail;
    private EditText etPwd;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);
        imageView = findViewById(R.id.imageView);
        textView = findViewById(R.id.textView);
        imageView.setOnTouchListener(new OnSwipeTouchListener(getApplicationContext()) {
            public void onSwipeTop() {
            }

            public void onSwipeRight() {
                if (count == 0) {
                    imageView.setImageResource(R.drawable.good_night_img);
                    //textView.setText("Night");
                    count = 1;
                } else {
                    imageView.setImageResource(R.drawable.good_morning_img);
                    //textView.setText("Morning");
                    count = 0;
                }
            }

            public void onSwipeLeft() {
                if (count == 0) {
                    imageView.setImageResource(R.drawable.good_night_img);
                    //textView.setText("Night");
                    count = 1;
                } else {
                    imageView.setImageResource(R.drawable.good_morning_img);
                    //textView.setText("Morning");
                    count = 0;
                }
            }

            public void onSwipeBottom() {
            }

        });

        etEmail = findViewById(R.id.et_email);
        etPwd = findViewById(R.id.et_password);


        findViewById(R.id.btn_sign_up).setOnClickListener(v -> startActivity(new Intent(LoginActivity.this, RegisterActivity.class)));

        findViewById(R.id.btn_login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goLogin();
            }
        });

    }

    private void goLogin() {

        String email = etEmail.getText().toString();
        String pwd = etPwd.getText().toString();

        if (email.trim().equals("")) {
            Toast.makeText(this, "Please enter email", Toast.LENGTH_SHORT).show();
            return;
        }


        SharedPreferences sharedPreferences = getSharedPreferences(Constants.PREFERENCES_FILE, Context.MODE_PRIVATE);

        // 判断本地有没有该用户
        if (sharedPreferences.contains(Constants.SHARE_PREF_USER_LIST)) {


            String userListString = sharedPreferences.getString(Constants.SHARE_PREF_USER_LIST, "");
            Gson gson = new Gson();
            // 字符串转成 list
            List<User> userArrayList = gson.fromJson(userListString, new TypeToken<List<User>>() {
            }.getType());

            // 如果list 不为空 里面有用户了

            boolean hasRegistered = false;
            boolean pwdMatch = false;

            User matchedUser = null;
            if (userArrayList != null && userArrayList.size() > 0) {
                for (int i = 0; i < userArrayList.size(); i++) {
                    User user = userArrayList.get(i);
                    String localUserEmail = user.getEmail();
                    String localUserPwd = user.getPwd();
                    if (localUserEmail.equals(email)) {
                        hasRegistered = true;
                        pwdMatch = pwd.equals(localUserPwd);
                        if (pwd.equals(localUserPwd)) {
                            matchedUser = user;
                        }
                    }
                }
            }


            if (hasRegistered) {
                // 判断密码对不对
                if (pwdMatch) {
                    // 登录成功
                    Toast.makeText(this, "Log in successful", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(LoginActivity.this, MainActivity.class));
                    App.instance.currentUser = matchedUser;
                    finish();
                } else {
                    Toast.makeText(this, "Wrong password", Toast.LENGTH_SHORT).show();
                }


            } else {
                Toast.makeText(this, "Wrong email", Toast.LENGTH_SHORT).show();
            }


        } else {
            Toast.makeText(this, "Please register", Toast.LENGTH_SHORT).show();
        }


    }
}
