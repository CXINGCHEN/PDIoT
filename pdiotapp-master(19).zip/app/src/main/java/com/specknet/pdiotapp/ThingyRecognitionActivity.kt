package com.specknet.pdiotapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Log
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet
import com.specknet.pdiotapp.bean.RecognitionResultBean
import com.specknet.pdiotapp.common.DelayRespek
import com.specknet.pdiotapp.common.RespekData
import com.specknet.pdiotapp.ml.MyTmodel
import com.specknet.pdiotapp.utils.Constants
import com.specknet.pdiotapp.utils.RecognitionResultHelper
import com.specknet.pdiotapp.utils.ThingyLiveData
import org.tensorflow.lite.DataType
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import java.util.concurrent.BlockingQueue
import java.util.concurrent.DelayQueue
import kotlin.math.roundToInt
import kotlin.math.sqrt

class ThingyRecognitionActivity : AppCompatActivity() {

    // prediction text
    lateinit var predictionProgressBar: ProgressBar
    lateinit var predictionText: TextView


    // global graph variables
    lateinit var dataSet_x: LineDataSet
    lateinit var dataSet_y: LineDataSet
    lateinit var dataSet_z: LineDataSet
    lateinit var dataSet_mag: LineDataSet
    var time = 0f
    lateinit var allAccelData: LineData
    lateinit var chart: LineChart


    // 存储每个动作识别到的次数
    val map = mutableMapOf<String, Int>()

    private var lastlabel = ""
    var count=0


    var thingyProbabilityArray: FloatArray = FloatArray(14)
    var thingyPointsNum = 0f
    var thingyDataPack = java.util.ArrayList<Float>(300)

    lateinit var thingyLiveUpdateReceiver: BroadcastReceiver
    lateinit var looperThingy: Looper
    val filterTestThingy = IntentFilter(Constants.ACTION_THINGY_BROADCAST)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_thingy_recognition)

        predictionProgressBar = findViewById(R.id.predicted_activity)
        predictionText = findViewById(R.id.predicted_activity_text)


        // get the accel fields
        val accel_x = findViewById<TextView>(R.id.live_x_accel_data)
        val accel_y = findViewById<TextView>(R.id.live_y_accel_data)
        val accel_z = findViewById<TextView>(R.id.live_z_accel_data)
        val gryo_x = findViewById<TextView>(R.id.live_gyro_x_data)
        val gryo_y = findViewById<TextView>(R.id.live_gyro_y_data)
        val gryo_z = findViewById<TextView>(R.id.live_gyro_z_data)

        setupGraph()


        // set up the broadcast receiver
        thingyLiveUpdateReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {

                Log.i("thread", "I am running on thread = " + Thread.currentThread().name)

                val action = intent.action

                if (action == Constants.ACTION_THINGY_BROADCAST) {

                    val liveData =
                        intent.getSerializableExtra(Constants.THINGY_LIVE_DATA) as ThingyLiveData
                    Log.d("Live", "onReceive: liveData = " + liveData)

                    val x = liveData.accelX
                    val y = liveData.accelY
                    val z = liveData.accelZ
                    val gx = liveData.gyro.x
                    val gy = liveData.gyro.y
                    val gz = liveData.gyro.z
                    val mag = sqrt((x * x + y * y + z * z).toDouble())
                    thingyPointsNum += 1
                    thingyDataPack.addAll(
                        arrayListOf(
                            x, y, z, gx, gy, gz
                        )
                    )

                    if (thingyPointsNum >= 50) {

                        if (thingyPointsNum % 50 == 0f) {

                            val model = MyTmodel.newInstance(context)

                            // Creates inputs for reference.
                            val inputFeature0 =
                                TensorBuffer.createFixedSize(intArrayOf(1, 50, 6), DataType.FLOAT32)
                            inputFeature0.loadArray(thingyDataPack.toFloatArray())

                            // Runs model inference and gets result.
                            val outputs = model.process(inputFeature0)
                            val outputFeature0 = outputs.outputFeature0AsTensorBuffer

                            thingyProbabilityArray = outputFeature0.floatArray

                            /*if (lastlabel.isNotEmpty()) {

                                when (lastlabel) {
                                    "Sitting straight", "Sitting bent forward", "Sitting bent backward", "Desk work" -> {
                                        thingyProbabilityArray[9] = 0f
                                        thingyProbabilityArray[10] = 0f
                                        thingyProbabilityArray[11] = 0f

                                    }
                                    "Lying down left", "Lying down right", "Lying down front", "Lying down back" -> {
                                        thingyProbabilityArray[8] = 0f
                                        thingyProbabilityArray[9] = 0f
                                        thingyProbabilityArray[10] = 0f
                                        thingyProbabilityArray[11] = 0f
                                    }
                                    "Walking" -> {
                                        thingyProbabilityArray[4] = 0f
                                        thingyProbabilityArray[5] = 0f
                                        thingyProbabilityArray[6] = 0f
                                        thingyProbabilityArray[7] = 0f
                                    }
                                    "Running", "Ascending stairs", "Descending stairs" -> {
                                        thingyProbabilityArray[0] = 0f
                                        thingyProbabilityArray[1] = 0f
                                        thingyProbabilityArray[2] = 0f
                                        thingyProbabilityArray[4] = 0f
                                        thingyProbabilityArray[5] = 0f
                                        thingyProbabilityArray[6] = 0f
                                        thingyProbabilityArray[7] = 0f
                                        thingyProbabilityArray[12] = 0f
                                    }
                                }

                            }*/


                            //  返回的第0
                            val tinyLstmConfidence =
                                thingyProbabilityArray.max()?.times(100)?.roundToInt()
                            val label = getLabelText(thingyProbabilityArray)
                            lastlabel = label
                            if (label == "Sitting straight" || label == "Sitting bent forward" || label == "Sitting bent backward" || label == "Desk work") {
                                count += 1
                                if(count==5){
                                    runOnUiThread {
                                        Toast.makeText(this@ThingyRecognitionActivity, "Sitting too long, Please relax for a while", Toast.LENGTH_SHORT).show()
                                    }
                                    count=0
                                }
                            }
                            else count=0

                            updateUI(label, tinyLstmConfidence)
                            Log.i("Tiny LSTM MODEL", label)

                            // 识别到几个动作 map里面就会有几个key
                            map[label] = map[label]?.plus(1) ?: 1


                            // Releases model resources if no longer used.
                            model.close()

                        }

                        thingyDataPack = java.util.ArrayList(thingyDataPack.drop(6))
                    }


                    updateGraph(x, y, z)

                    /*//  ---  Graph  ---
                    val data = RespekData(0L, x, y, z, gx, gy, gz, mag.toFloat(), 0f)
                    val delayRespek = DelayRespek(data, 79)
                    mDelayRespeckQueue.add(delayRespek)

                    runOnUiThread {
                        accel_x.text = "accel_x = $x"
                        accel_y.text = "accel_y = $y"
                        accel_z.text = "accel_z = $z"
                        gryo_x.text = "gryo_x = $gx"
                        gryo_y.text = "gryo_y = $gy"
                        gryo_z.text = "gryo_z = $gz"
                    }
                    time++
                    updateGraph()*/


                }
            }
        }

        // register receiver on another thread
        val handlerThreadThingy = HandlerThread("bgThreadThingyLive")
        handlerThreadThingy.start()
        looperThingy = handlerThreadThingy.looper
        val handlerThingy = Handler(looperThingy)
        this.registerReceiver(thingyLiveUpdateReceiver, filterTestThingy, null, handlerThingy)
    }


    val labels = listOf(
        "Sitting straight",
        "Sitting bent forward",
        "Sitting bent backward",
        "Standing",
        "Lying down left",
        "Lying down right",
        "Lying down front",
        "Lying down back",
        "Walking",
        "Running",
        "Ascending stairs",
        "Descending stairs",
        "Desk work",
        "General movement"
    )


    fun getLabelText(predictions: FloatArray): String {
        var max = Float.MIN_VALUE
        var maxIdx = -1
        for (i in labels.indices) {
            if (predictions[i] > max) {
                max = predictions[i]
                maxIdx = i
            }
        }
        return labels[maxIdx]
    }


    private fun setupGraph() {
        chart = findViewById(R.id.chart)
        time = 0f
        val entries_x = ArrayList<Entry>()
        val entries_y = ArrayList<Entry>()
        val entries_z = ArrayList<Entry>()
        val entries_gx = ArrayList<Entry>()
        val entries_gy = ArrayList<Entry>()
        val entries_gz = ArrayList<Entry>()
        val entries_mag = ArrayList<Entry>()

        dataSet_x = LineDataSet(entries_x, "Accel X")
        dataSet_y = LineDataSet(entries_y, "Accel Y")
        dataSet_z = LineDataSet(entries_z, "Accel Z")

        dataSet_mag = LineDataSet(entries_mag, "Magnitude")

        dataSet_x.setDrawCircles(false)
        dataSet_y.setDrawCircles(false)
        dataSet_z.setDrawCircles(false)

        dataSet_mag.setDrawCircles(false)

        dataSet_x.setColor(
            ContextCompat.getColor(
                this, R.color.red
            )
        )
        dataSet_y.setColor(
            ContextCompat.getColor(
                this, R.color.green
            )
        )
        dataSet_z.setColor(
            ContextCompat.getColor(
                this, R.color.blue
            )
        )

        dataSet_mag.setColor(
            ContextCompat.getColor(
                this, R.color.yellow
            )
        )

        val dataSets = ArrayList<ILineDataSet>()
        dataSets.add(dataSet_x)
        dataSets.add(dataSet_y)
        dataSets.add(dataSet_z)
        dataSets.add(dataSet_mag)

        allAccelData = LineData(dataSets)
        chart.data = allAccelData
        // 控件重绘
        chart.invalidate()
    }

    fun updateGraph(x: Float, y: Float, z: Float) {
        // take the first element from the queue
        // and update the graph with it

        dataSet_x.addEntry(Entry(thingyPointsNum, x))
        dataSet_y.addEntry(Entry(thingyPointsNum, y))
        dataSet_z.addEntry(Entry(thingyPointsNum, z))


        runOnUiThread {
            allAccelData.notifyDataChanged()
            chart.notifyDataSetChanged()
            chart.invalidate()
            chart.setVisibleXRangeMaximum(150f)
            chart.moveViewToX(chart.lowestVisibleX + 40)
        }
    }

    fun updateUI(prediction: String, confidence: Int?) {
        runOnUiThread {
            predictionProgressBar.progress = confidence as Int
            predictionText.text = prediction

        }
    }

    override fun onDestroy() {

        unregisterReceiver(thingyLiveUpdateReceiver)
        looperThingy.quit()

        val list = ArrayList<RecognitionResultBean>()
        map.forEach { (label, count) ->
            list.add(RecognitionResultBean(System.currentTimeMillis(), label, count, "respeck"))
        }
        // 页面关闭的时候把数据存入本地
        if (list.isNotEmpty()) {
            // 存储在本地
            RecognitionResultHelper.saveUserRecognitionData(list)
        }
        // 先执行我们的代码 再Destroy
        super.onDestroy()
    }
}