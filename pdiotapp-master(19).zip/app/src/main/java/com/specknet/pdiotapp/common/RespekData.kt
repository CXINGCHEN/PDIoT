package com.specknet.pdiotapp.common

class RespekData(val timestamp: Long, val accel_x: Float, val accel_y: Float,
                 val accel_z: Float,val gyro_x: Float, val gyro_y: Float,
                 val gyro_z: Float, val accel_mag: Float, val breathingSignal: Float)