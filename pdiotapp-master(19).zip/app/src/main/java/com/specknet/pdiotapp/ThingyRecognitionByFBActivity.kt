package com.specknet.pdiotapp

import android.os.Bundle
import android.util.Log
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet
import com.google.firebase.ml.modeldownloader.CustomModelDownloadConditions
import com.google.firebase.ml.modeldownloader.DownloadType
import com.google.firebase.ml.modeldownloader.FirebaseModelDownloader
import com.specknet.pdiotapp.bean.RecognitionResultBean
import com.specknet.pdiotapp.common.DelayRespek
import com.specknet.pdiotapp.common.RecognitionDataManager
import com.specknet.pdiotapp.common.RespekData
import com.specknet.pdiotapp.common.TFLiteModelByFile
import com.specknet.pdiotapp.utils.RecognitionResultHelper
import org.tensorflow.lite.Interpreter
import java.util.concurrent.BlockingQueue
import java.util.concurrent.DelayQueue
import kotlin.math.roundToInt
import kotlin.math.sqrt

class ThingyRecognitionByFBActivity : AppCompatActivity() {

    // display queue to update the graph smoothly
    private var mDelayRespeckQueue: BlockingQueue<DelayRespek> = DelayQueue()

    // prediction text
    lateinit var predictionProgressBar: ProgressBar
    lateinit var predictionText: TextView


    // global graph variables
    lateinit var dataSet_x: LineDataSet
    lateinit var dataSet_y: LineDataSet
    lateinit var dataSet_z: LineDataSet
    lateinit var dataSet_gx: LineDataSet
    lateinit var dataSet_gy: LineDataSet
    lateinit var dataSet_gz: LineDataSet
    lateinit var dataSet_mag: LineDataSet
    var time = 0f
    lateinit var allAccelData: LineData
    lateinit var chart: LineChart

    var thingyModel: TFLiteModelByFile? = null

    // 存储每个动作识别到的次数
    val map = mutableMapOf<String, Int>()

    private var lastlabel = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_thingy_recognition_by_fb)

        predictionProgressBar = findViewById(R.id.predicted_activity)
        predictionText = findViewById(R.id.predicted_activity_text)


        val conditions = CustomModelDownloadConditions.Builder().build()
        FirebaseModelDownloader.getInstance()
            .getModel("TTmodel", DownloadType.LOCAL_MODEL, conditions).addOnSuccessListener {
                Log.d("FirebaseModelDownloader", "onsuccess")
                val name = it.name
                val localFilePath = it.localFilePath
                Log.d("FirebaseModelDownloader", "name=$name, localFilePath=$localFilePath")
                val file = it.file
                if (file != null) {
                    thingyModel = TFLiteModelByFile(assets, file, "model.txt", 14, 50)
                }
            }.addOnFailureListener {
                it.printStackTrace()
                Log.d("FirebaseModelDownloader", "on fail")
                Toast.makeText(this, "模型加载失败", Toast.LENGTH_SHORT).show()
            }.addOnCompleteListener {
                Log.d("FirebaseModelDownloader", "on complete")
                // Download complete. Depending on your app, you could enable the ML
                // feature, or switch from the local model to the remote model, etc.
            }


        // get the accel fields
        val accel_x = findViewById<TextView>(R.id.live_x_accel_data)
        val accel_y = findViewById<TextView>(R.id.live_y_accel_data)
        val accel_z = findViewById<TextView>(R.id.live_z_accel_data)
        val gryo_x = findViewById<TextView>(R.id.live_gyro_x_data)
        val gryo_y = findViewById<TextView>(R.id.live_gyro_y_data)
        val gryo_z = findViewById<TextView>(R.id.live_gyro_z_data)

        setupGraph()

        // 监听thingy数据
        RecognitionDataManager.onThingyDataUpdate = { dataList ->
            if (dataList.isNotEmpty()) {
                Log.d("Live", "onReceive: liveData = " + dataList[0])
                val liveData = dataList[0]
                val x = liveData.accelX
                val y = liveData.accelY
                val z = liveData.accelZ
                val gx = liveData.gyro.x
                val gy = liveData.gyro.y
                val gz = liveData.gyro.z
                val mag = sqrt((x * x + y * y + z * z).toDouble())

                // for循环 push5次
                dataList.forEach {
                    // new tflite model
                    thingyModel?.pushNewData(x, y, z, gx, gy, gz)
                }
                // 满五个数据才调用一次
                val tinyLstmPerdictions = thingyModel?.classify()


                if (lastlabel.isNotEmpty() && tinyLstmPerdictions != null) {

                    when (lastlabel) {
                        "Sitting straight", "Sitting bent forward", "Sitting bent backward", "Desk work" -> {
                            tinyLstmPerdictions[0][9] = 0f
                            tinyLstmPerdictions[0][10] = 0f
                            tinyLstmPerdictions[0][11] = 0f

                        }
                        "Lying down left", "Lying down right", "Lying down front", "Lying down back" -> {
                            tinyLstmPerdictions[0][8] = 0f
                            tinyLstmPerdictions[0][9] = 0f
                            tinyLstmPerdictions[0][10] = 0f
                            tinyLstmPerdictions[0][11] = 0f
                        }
                        "Walking" -> {
                            tinyLstmPerdictions[0][4] = 0f
                            tinyLstmPerdictions[0][5] = 0f
                            tinyLstmPerdictions[0][6] = 0f
                            tinyLstmPerdictions[0][7] = 0f
                        }
                        "Running", "Ascending stairs", "Descending stairs" -> {
                            tinyLstmPerdictions[0][0] = 0f
                            tinyLstmPerdictions[0][1] = 0f
                            tinyLstmPerdictions[0][2] = 0f
                            tinyLstmPerdictions[0][4] = 0f
                            tinyLstmPerdictions[0][5] = 0f
                            tinyLstmPerdictions[0][6] = 0f
                            tinyLstmPerdictions[0][7] = 0f
                            tinyLstmPerdictions[0][12] = 0f
                        }
                    }

                }

                if (tinyLstmPerdictions != null) {
                    //  返回的第0
                    val tinyLstmConfidence = tinyLstmPerdictions[0].max()?.times(100)?.roundToInt()
                    val label = thingyModel?.getLabelText(tinyLstmPerdictions)
                    lastlabel = label ?: ""
                    updateUI(thingyModel?.getLabelText(tinyLstmPerdictions) ?: "", tinyLstmConfidence)
                    Log.i("Tiny LSTM MODEL", label ?:"")

                    // 识别到几个动作 map里面就会有几个key
                    map[label ?: ""] = map[label]?.plus(1) ?: 1

                    // TODO: 存数据

                    //  ---  Graph  ---
                    val data = RespekData(0L, x, y, z, gx, gy, gz, mag.toFloat(), 0f)
                    val delayRespek = DelayRespek(data, 79)
                    mDelayRespeckQueue.add(delayRespek)

                    runOnUiThread {
                        accel_x.text = "accel_x = $x"
                        accel_y.text = "accel_y = $y"
                        accel_z.text = "accel_z = $z"
                        gryo_x.text = "gryo_x = $gx"
                        gryo_y.text = "gryo_y = $gy"
                        gryo_z.text = "gryo_z = $gz"
                    }
                    time++
                    updateGraph()
                }



            }

        }
    }


    private fun setupGraph() {
        chart = findViewById(R.id.chart)
        time = 0f
        val entries_x = ArrayList<Entry>()
        val entries_y = ArrayList<Entry>()
        val entries_z = ArrayList<Entry>()
        val entries_gx = ArrayList<Entry>()
        val entries_gy = ArrayList<Entry>()
        val entries_gz = ArrayList<Entry>()
        val entries_mag = ArrayList<Entry>()

        dataSet_x = LineDataSet(entries_x, "Accel X")
        dataSet_y = LineDataSet(entries_y, "Accel Y")
        dataSet_z = LineDataSet(entries_z, "Accel Z")

        dataSet_gx = LineDataSet(entries_gx, "Gyro X")
        dataSet_gy = LineDataSet(entries_gy, "Gyro Y")
        dataSet_gz = LineDataSet(entries_gz, "Gyro Z")

        dataSet_mag = LineDataSet(entries_mag, "Magnitude")

        dataSet_x.setDrawCircles(false)
        dataSet_y.setDrawCircles(false)
        dataSet_z.setDrawCircles(false)

        dataSet_gx.setDrawCircles(false)
        dataSet_gy.setDrawCircles(false)
        dataSet_gz.setDrawCircles(false)

        dataSet_mag.setDrawCircles(false)

        dataSet_x.setColor(
            ContextCompat.getColor(
                this, R.color.red
            )
        )
        dataSet_y.setColor(
            ContextCompat.getColor(
                this, R.color.green
            )
        )
        dataSet_z.setColor(
            ContextCompat.getColor(
                this, R.color.blue
            )
        )

        dataSet_gx.setColor(
            ContextCompat.getColor(
                this, R.color.amber
            )
        )
        dataSet_gy.setColor(
            ContextCompat.getColor(
                this, R.color.brown
            )
        )
        dataSet_gz.setColor(
            ContextCompat.getColor(
                this, R.color.deep_purple
            )
        )

        dataSet_mag.setColor(
            ContextCompat.getColor(
                this, R.color.yellow
            )
        )

        val dataSets = ArrayList<ILineDataSet>()
        dataSets.add(dataSet_x)
        dataSets.add(dataSet_y)
        dataSets.add(dataSet_z)
        dataSets.add(dataSet_gx)
        dataSets.add(dataSet_gy)
        dataSets.add(dataSet_gz)
        dataSets.add(dataSet_mag)

        allAccelData = LineData(dataSets)
        chart.data = allAccelData
        // 控件重绘
        chart.invalidate()
    }

    fun updateGraph() {
        // take the first element from the queue
        // and update the graph with it
        val respeckData = mDelayRespeckQueue.take().getData()

        dataSet_x.addEntry(Entry(time, respeckData.accel_x))
        dataSet_y.addEntry(Entry(time, respeckData.accel_y))
        dataSet_z.addEntry(Entry(time, respeckData.accel_z))

        dataSet_gx.addEntry(Entry(time, respeckData.gyro_x))
        dataSet_gy.addEntry(Entry(time, respeckData.gyro_y))
        dataSet_gz.addEntry(Entry(time, respeckData.gyro_z))


        runOnUiThread {
            allAccelData.notifyDataChanged()
            chart.notifyDataSetChanged()
            chart.invalidate()
            chart.setVisibleXRangeMaximum(150f)
            chart.moveViewToX(chart.lowestVisibleX + 40)
        }
    }

    fun updateUI(prediction: String, confidence: Int?) {
        runOnUiThread {
            predictionProgressBar.progress = confidence as Int
            predictionText.text = prediction

        }
    }

    override fun onDestroy() {

        val list = ArrayList<RecognitionResultBean>()
        map.forEach { (label, count) ->
            list.add(RecognitionResultBean(System.currentTimeMillis(), label, count, "respeck"))
        }
        // 页面关闭的时候把数据存入本地
        if (list.isNotEmpty()) {
            // 存储在本地
            RecognitionResultHelper.saveUserRecognitionData(list)
        }
        // 先执行我们的代码 再Destroy
        super.onDestroy()
    }
}