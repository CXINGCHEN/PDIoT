package com.specknet.pdiotapp.network

class PredictionRequest {
    var data: Array<Array<FloatArray>> = arrayOf(Array(50) { FloatArray(6) })
}