package com.specknet.pdiotapp;

import android.app.Application;
import android.util.Log;

import com.google.firebase.FirebaseApp;
import com.specknet.pdiotapp.bean.User;

public class App extends Application {

    public static final String TAG = "App";


    public static App instance;

    // 登录成功之后就有值了
    public User currentUser = null;


    @Override
    public void onCreate() {
        Log.d(TAG, "onCreate() called");
        super.onCreate();
        instance = this;
        FirebaseApp.initializeApp(this);
    }

    public Application getApp() {
        return instance;
    }


}
